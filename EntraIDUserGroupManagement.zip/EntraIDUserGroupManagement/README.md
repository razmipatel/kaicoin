# Plugin Example
Project for an example plugin to show how to create custom endpoint

