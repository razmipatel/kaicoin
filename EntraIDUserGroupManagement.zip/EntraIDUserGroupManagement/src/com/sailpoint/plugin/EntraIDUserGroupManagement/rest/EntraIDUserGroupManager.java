package com.sailpoint.plugin.EntraIDUserGroupManagement.rest;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import sailpoint.object.*;
import sailpoint.api.*;
import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.rest.plugin.RequiredRight;
import sailpoint.server.Auditor;
import sailpoint.tools.GeneralException;
import sailpoint.tools.GeneralException;
import sailpoint.tools.Message;
import sailpoint.tools.Util;
import sailpoint.tools.xml.XMLReferenceResolver;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.Operation;
import sailpoint.object.RpcResponse;
import sailpoint.object.RpcRequest;
import sailpoint.object.Rule;
import sailpoint.connector.RPCService;
import sailpoint.api.SailPointFactory;
import sailpoint.object.Application;
import sailpoint.object.AuditConfig;
import sailpoint.object.AuditConfig.AuditAttribute;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Path("EntraIDUserGroupManager")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@RequiredRight("EntraIDUserGroupManagementPluginRight")
public class EntraIDUserGroupManager extends BasePluginResource {

	private static final Log	log	= LogFactory.getLog(EntraIDUserGroupManager.class);
	private Response			response;
	private String applicationName = "Entra ID";

	public String getSettingSting(String Key) {
		return getSettingString(Key);
	}

	public String getPluginName() {

		return "EntraIDUserGroupManager";
	}

	private void createAuditEvent(String action, String username, String objectid, String attributeName, Attributes eventAt) {
		try {
			SailPointContext context = SailPointFactory.getCurrentContext();
			Date currentDate= new Date();
			SimpleDateFormat sdf =new SimpleDateFormat("MM/dd/yyyy");
			String curDate = sdf.format(currentDate);

			if (Auditor.isEnabled(action)){
				AuditEvent event = new AuditEvent();
				event.setTarget(username);
				log.trace("in audit event");
				event.setAction(action);
				event.setApplication(applicationName);
				event.setAttributeName(attributeName);
				event.setAttributeValue(objectid);
				event.setAttributes(eventAt);
				event.setString1(curDate);
				Auditor.log(event);
				log.trace("event ends");
				context.commitTransaction();
			}
		}catch (Exception e) {

			log.error ("Error in auditing event");
		}

		return;
	}

	private int getIdentityCount(SailPointContext context, String username) {
		int count =0;
		try {
			QueryOptions qo = new QueryOptions();
			Filter filter = Filter.eq("name", username);
			qo.addFilter(filter);
			count = context.countObjects(Identity.class, qo);
			return count;
		}catch (Exception e) {
			log.trace("Exception in getIdentityCount method");
			log.trace(e);
		}
		return count;
	}

	private List getManagedObjects (SailPointContext context, String appName, String objectType, String objectName) {
		log.trace("Entering getManagedAttribute");
		List managedAttr = new ArrayList();
		try {
			QueryOptions qo = new QueryOptions();
			Filter filter = Filter.eq("displayName", objectName);
			filter.and(Filter.eq("type", objectType));
			filter.and(Filter.eq("application.name", appName));
			qo.addFilter(filter);
			managedAttr = context.getObjects(ManagedAttribute.class, qo);
		}catch (Exception e) {
			log.trace("Exception in getManagedAttribute method");
			log.trace(e);
		}
		log.trace("Exiting getManagedAttribute");
		return managedAttr;
	}

	@POST
	@Path("createB2BUser")
	public Response createB2BUser(Map<String, Object> request) throws GeneralException, SQLException, ParseException {
		log.trace("Entering createB2BUser...");
		log.debug(getSettingString("TenantID"));
		log.debug(getSettingString("EntraIDAppName"));
		SailPointContext context = SailPointFactory.getCurrentContext();
		String firstname = (String)request.get("firstname");
		String lastname = (String)request.get("lastname");
		String email = (String)request.get("email");
		String company = (String)request.get("partner");
		String manager = (String)request.get("manager");
		String startDate = (String)request.get("startDate");
		String endDate = (String)request.get("endDate");
		String responseString = "Success";
		try {

			if(Util.isNullOrEmpty(firstname)||Util.isNullOrEmpty(lastname)||Util.isNullOrEmpty(email)||Util.isNullOrEmpty(manager)||Util.isNullOrEmpty(startDate)||Util.isNullOrEmpty(endDate)) {
				responseString = "Mandatory inputs missing";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			String username = firstname+" "+lastname+" ("+company+")";
			log.trace("firstname:"+firstname);
			log.trace("lastname:"+lastname);
			log.trace("email:"+email);
			log.trace("username:"+username);

			//Step1: Check if manager is existing in the system
			int count = getIdentityCount(context, manager);
			if(count<=0) {
				responseString = "Manager is not present in IIQ";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;            	
			}

			//Step2: Check if Identity is Already existing

			int counter = 1;
			boolean unique = false;
			count = getIdentityCount(context, username);
			if(count>0) {
				while(!unique) {
					log.debug("User "+username+" exists in the system; Adding a number to last name");
					username = firstname+" "+lastname+counter+" ("+company+")";
					count = getIdentityCount(context, username);
					if(count<=0) {
						unique=true;
						break;
					}
					counter+=1;
				}
			}

			//Step 3: create identity
			SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			df.setLenient(false);
			Date SD = df.parse(startDate);
			Date ED = df.parse(endDate);
			Identity identity = new Identity();
			identity.setName(username);
			identity.setFirstname(firstname);
			identity.setLastname(lastname);
			identity.setEmail(email);
			identity.setManager(context.getObjectByName(Identity.class, manager));
			identity.setAttribute("startDate", SD);
			identity.setAttribute("endDate", ED);
			identity.setAttribute("company", company);
			identity.setType("B2BUser");
			context.saveObject(identity);
			context.commitTransaction();

			//Step 4: Azure Account
			ProvisioningPlan plan = new ProvisioningPlan();
			plan.setIdentity(identity);
			ProvisioningPlan.AccountRequest requestAccount = new ProvisioningPlan.AccountRequest();
			requestAccount.setNativeIdentity(username);
			requestAccount.setOperation(ProvisioningPlan.AccountRequest.Operation.Create);
			requestAccount.setApplication(applicationName);
			requestAccount.add( new ProvisioningPlan.AttributeRequest("accountType", ProvisioningPlan.Operation.Add, "Guest User B2B" ));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("invitedUserEmailAddress", ProvisioningPlan.Operation.Add, email));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("invitedUserDisplayName", ProvisioningPlan.Operation.Add, username));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("inviteRedirectUrl", ProvisioningPlan.Operation.Add, "http://demo.com/redirect\"" ));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("usageLocation", ProvisioningPlan.Operation.Set, "United States;US" ));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("sendInvitationMessage", ProvisioningPlan.Operation.Add, Boolean.TRUE ));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("accountEnabled", ProvisioningPlan.Operation.Set, Boolean.TRUE ));
			requestAccount.add( new ProvisioningPlan.AttributeRequest("forceChangePasswordNextLogin", ProvisioningPlan.Operation.Add, Boolean.TRUE ));

			String groupid = null;
			//Find users default group ID
			List managedAttr = getManagedObjects(context,applicationName, "group", company);
			log.debug("managedAttr::"+managedAttr);
			if(managedAttr!=null && managedAttr.size()>0) {
				log.trace("group found");
				Iterator itr = managedAttr.iterator();
				while(itr.hasNext()) {
					ManagedAttribute at = (ManagedAttribute) itr.next();
					log.trace("groupID for default user group is :: "+at.getValue());
					groupid = at.getValue();		  			
				}
				sailpoint.tools.Util.flushIterator(itr);
			}

			//Step 5: Audit Create user event
			Date currentDate= new Date();
			String curDate = df.format(currentDate);

			String action = "Create";
			if (Auditor.isEnabled(action)){
				AuditEvent event = new AuditEvent();
				event.setTarget(username);
				log.trace("in audit event");
				event.setAction(action);
				event.setString1(curDate);
				Auditor.log(event);
				log.trace("event ends");
				context.commitTransaction();

			}

			if(groupid == null || groupid.isEmpty()) {
				responseString = "B2B user creation success. Default group does not exisit in EntraID/SailPoint and EntraID account is not created.";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
				return response;
			}


			//Step 6: add user to default group
			Map map = new HashMap();
			map.put("assignment", "true");
			Attributes at = new Attributes();
			at.putAll(map);
			ProvisioningPlan.AttributeRequest attribute = new ProvisioningPlan.AttributeRequest();
			attribute.setValue(groupid);
			attribute.setOp(ProvisioningPlan.Operation.Add);
			attribute.setName("groups");
			attribute.setArgs(at);
			requestAccount.add(attribute);
			plan.add(requestAccount);
			log.trace(plan.toXml());

			//Step 7:execute provisioning plan
			Provisioner p = new Provisioner(context);
			p.execute(plan);
			log.trace("added user to group");

			responseString = "User created successfully";
			response = Response.status(Response.Status.OK).entity(responseString).build(); 

		}catch(Exception e) {
			log.trace(e);
		}

		log.trace("Exiting createB2BUser...");

		return response;
	}


	@DELETE
	@Path("deleteB2BUser")
	public Response deleteB2BUser(Map<String, Object> request) throws GeneralException, SQLException, ParseException {
		log.trace("Entering deleteB2BUser...");
		String email = (String)request.get("email");
		String company = (String)request.get("partner");
		SailPointContext context = SailPointFactory.getCurrentContext();
		String username,nativeIdentity = null;
		String responseString = "Success";
		ProvisioningPlan plan;
		Provisioner p;
		try {

			if(Util.isNullOrEmpty(email)||Util.isNullOrEmpty(company)) {
				responseString = "Mandatory inputs missing";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;				
			}

			QueryOptions qo = new QueryOptions();
			Filter filter = Filter.eq("email", email);
			filter.and(Filter.eq("type", "B2BUser"));
			filter.and(Filter.eq("company", company));
			qo.addFilter(filter);
			List identities = context.getObjects(Identity.class, qo);

			if(Util.isEmpty(identities)) {
				responseString = "User not found in IIQ";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;	
			}
			log.debug("number of identities to delete::"+identities.size());
			Iterator iter = identities.iterator();
			while ( (null != iter) && (iter.hasNext()) ) {
				Identity identity = (Identity) iter.next();
				username = identity.getName();

				//check if user has EntraID Link, delete the Entra ID account
				List links = identity.getLinks();
				if(!Util.isEmpty(links)) {
					Iterator linkIt = links.iterator();
					while(linkIt.hasNext()) {
						Link li = (Link) linkIt.next();
						log.trace("link application::"+li.getApplicationName()+" Native identity::"+li.getNativeIdentity());
						if(li.getApplicationName().equalsIgnoreCase(applicationName)) {
							nativeIdentity=li.getNativeIdentity();
						}
						log.debug("deleting EntraID account for::"+nativeIdentity);
						plan = new ProvisioningPlan();
						plan.setIdentity(identity);
						ProvisioningPlan.AccountRequest requestAccount = new ProvisioningPlan.AccountRequest();
						requestAccount.setNativeIdentity(nativeIdentity);
						requestAccount.setOperation(ProvisioningPlan.AccountRequest.Operation.Delete);
						requestAccount.setApplication(applicationName);
						requestAccount.setAttributeRequests(new ArrayList());
						plan.add(requestAccount);
						log.debug(plan.toXml());
						p = new Provisioner(context);
						p.execute(plan);
					}
				}

				log.trace("deleting B2B Identity:"+identity.getName());
				Terminator terminate = new Terminator(context);
				terminate.deleteObject(identity);

				//Audit event
				Date currentDate= new Date();
				SimpleDateFormat sdf =new SimpleDateFormat("MM/dd/yyyy");
				String curDate = sdf.format(currentDate);

				String action = "Delete";
				if (Auditor.isEnabled(action)){
					AuditEvent event = new AuditEvent();
					event.setTarget(username);
					log.trace("in audit event");
					event.setAction(action);
					event.setString1(curDate);
					Auditor.log(event);
					log.trace("event ends");
					//context.commitTransaction();

				}
				//Removing it from Cache
				context.decache(identity);		
			}
			context.commitTransaction();
			sailpoint.tools.Util.flushIterator(iter);


			responseString = "User deleted successfully";
			response = Response.status(Response.Status.OK).entity(responseString).build(); 

		}catch(Exception e) {
			log.trace(e);
		}

		log.trace("Exiting deleteB2BUser...");

		return response;
	}

	@POST
	@Path("addRemovePIMGroup")
	public Response addRemovePIMGroup(Map<String, Object> request) throws GeneralException, SQLException, ParseException {
		log.trace("Entering addRemovePIMGroup...");
		SailPointContext context = SailPointFactory.getCurrentContext();
		String username = (String)request.get("username");
		String groupname = (String)request.get("groupname");
		String op = (String)request.get("operation");
		String groupid = null;
		String nativeIdentity = null;
		String responseString = "Success";
		try {			
			log.trace("username:"+username);
			log.trace("groupname:"+groupname);

			if(Util.isNullOrEmpty(username)||Util.isNullOrEmpty(groupname)||Util.isNullOrEmpty(op)) {
				responseString = "Mandatory inputs missing";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			if(!(op.equalsIgnoreCase("add")||op.equalsIgnoreCase("remove"))) {
				log.error("Invalid Operation");
				responseString = "Invalid Operation";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
				return response;				
			}

			log.trace("cheking if identity exists...");
			Identity identity = context.getObjectByName(Identity.class, username);
			if(identity == null) {
				responseString = "User is not present in IIQ";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}else {
				log.debug("get Entra ID link for user and find the object ID");
				List links = identity.getLinks();
				Iterator linkIt = links.iterator();
				while(linkIt.hasNext()) {
					Link li = (Link) linkIt.next();
					log.trace("link application::"+li.getApplicationName()+" Native identity::"+li.getNativeIdentity());
					if(li.getApplicationName().equalsIgnoreCase(applicationName)) {
						nativeIdentity=li.getNativeIdentity();
					}
				}
			}

			if(nativeIdentity == null) {
				responseString = "User does not have EntraID Account";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			log.trace("Checking if group exists...");
			QueryOptions qo = new QueryOptions();
			Filter filter = Filter.eq("displayName", groupname);
			filter.and(Filter.eq("type", "group"));
			filter.and(Filter.eq("application.name", applicationName));
			qo.addFilter(filter);
			List managedAttr = context.getObjects(ManagedAttribute.class, qo);
			if(managedAttr!=null && managedAttr.size()>0) {
				log.trace("group found");
				Iterator itr = managedAttr.iterator();
				while(itr.hasNext()) {
					ManagedAttribute at = (ManagedAttribute) itr.next();
					log.trace("attribtue value used to build the plan::"+at.getValue());
					groupid = at.getValue();		  			
				}
				sailpoint.tools.Util.flushIterator(itr);

			}else {
				log.trace("Group does not exist in SailPoint. Run the EntraID aggregation and verify if group is present in SailPoint");
				responseString = "Group does not exist in SailPoint. Run the EntraID aggregation and verify if group is present in SailPoint";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			// Call Audit event
			Attributes eventAt = new Attributes();
			eventAt.put("identity", identity.getDisplayableName());
			eventAt.put("Application", applicationName);
			eventAt.put("PIM Eligible Group Name", groupname);
			eventAt.put("Native identity", nativeIdentity);
			eventAt.put("Special Message", "This is a fire and forget call as Native connector does not support PIM Eligible Group Assignment");
			String action = "EntitlementAdd";
			if(op.equalsIgnoreCase("remove")) {
				action = "EntitlementRemove";
			}
			createAuditEvent(action, username, groupid, "group", eventAt);


			log.trace("launching powershell - fire and forget");
			String ruleName = "EntraId Powershell - Beanshell";

			HashMap argMap = new HashMap();
			argMap.put("username",nativeIdentity);
			argMap.put("groupname",groupid);
			argMap.put("operation",op);
			log.trace("calling beanshell rule with the user name::"+argMap.get("username")+" and group name::"+argMap.get("groupname")+" and operation::"+argMap.get("operation"));
			Rule rule = context.getObjectByName(Rule.class, ruleName);
			context.runRule(rule, argMap);
			log.trace("Done");  

		}catch(Exception e) {
			log.trace(e);
		}

		log.trace("Exiting groupUpdate......");
		responseString = "Success";
		response = Response.status(Response.Status.OK).entity(responseString).build();
		return response;
	}

	@PUT
	@Path("addRemoveGroup")
	public Response addRemoveGroup(Map<String, Object> request) throws GeneralException, SQLException, ParseException {
		log.trace("Entering addRemoveGroup...");
		SailPointContext context = SailPointFactory.getCurrentContext();
		String username = (String)request.get("username");
		String groupname = (String)request.get("groupname");
		String op = (String)request.get("operation");
		String groupid = null;
		String nativeIdentity = null;
		String responseString = null;
		boolean removeGrp = false;
		List identityGroups = new ArrayList();
		log.trace("username:"+username);
		log.trace("groupname:"+groupname);

		try {
			log.trace("cheking if identity exists...");
			Identity identity = context.getObjectByName(Identity.class, username);
			if(Util.isNullOrEmpty(username)||Util.isNullOrEmpty(groupname)||Util.isNullOrEmpty(op)) {
				responseString = "Mandatory inputs missing";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}
			if(identity == null) {
				responseString = "User is not present in IIQ";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}else {
				log.debug("get Entra ID link for user and find the object ID");
				List links = identity.getLinks();
				Iterator linkIt = links.iterator();
				while(linkIt.hasNext()) {
					Link li = (Link) linkIt.next();
					log.trace("link application::"+li.getApplicationName()+" Native identity::"+li.getNativeIdentity());
					if(li.getApplicationName().equalsIgnoreCase(applicationName)) {
						nativeIdentity=li.getNativeIdentity();
						identityGroups.addAll(Util.otol(li.getAttribute("groups"), true));
					}
				}
			}

			if(nativeIdentity == null) {
				responseString = "User does not have EntraID Account";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}


			ProvisioningPlan plan = new ProvisioningPlan();
			// Operation: Add user to group
			//Step1: Check if Group Exists
			log.trace("Checking if group exists...");
			List managedAttr = getManagedObjects(context,applicationName, "group", groupname);
			if(managedAttr!=null && managedAttr.size()>0) {
				log.trace("group found");
				Iterator itr = managedAttr.iterator();
				while(itr.hasNext()) {
					ManagedAttribute at = (ManagedAttribute) itr.next();
					log.trace("attribtue value used to build the plan::"+at.getValue());
					groupid = at.getValue();		  			
				}
				sailpoint.tools.Util.flushIterator(itr);

			}else {
				log.trace("Group does not exist in SailPoint. Run the EntraID aggregation and verify if group is present in SailPoint");
				responseString = "Group does not exist in SailPoint. Run the EntraID aggregation and verify if group is present in SailPoint";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			log.debug("op::"+op);

			//Step 1: Check if user has the group
			if(identityGroups == null || identityGroups.isEmpty()) {
				log.error("User does not have groups");
			}else {
				Iterator grpItr = identityGroups.iterator();
				while (grpItr.hasNext()) {
					if(grpItr.next().equals(groupid)) {
						removeGrp = true;
						break;
					}
				}
			}
			if(op.equalsIgnoreCase("remove")) {
				if(!removeGrp) {
					log.error("Remove group fail: User is not a member of requested group");
					responseString = "Remove group fail: User is not a member of requested group";
					response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
					return response;
				}
			}else if(op.equalsIgnoreCase("add")) {
				if(removeGrp) {
					log.error("User is already a member of the group");
					responseString = "User is already a member of the group";
					response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
					return response;
				}
			}else {
				log.error("Invalid Operation");
				responseString = "Invalid Operation";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
				return response;

			}
			log.debug("bulding plan for group update::"+groupid+"::native identity::"+nativeIdentity);

			//Step 2: Build provisioning plan to add user to group
			Attributes eventAt = new Attributes();
			eventAt.put("identity", identity.getDisplayableName());
			plan.setIdentity(identity);
			eventAt.put("Application", applicationName);
			ProvisioningPlan.AccountRequest requestAccount = new ProvisioningPlan.AccountRequest();
			requestAccount = new ProvisioningPlan.AccountRequest();
			requestAccount.setNativeIdentity(nativeIdentity);
			requestAccount.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
			requestAccount.setApplication(applicationName);
			Map map = new HashMap();
			map.put("assignment", "true");
			Attributes at = new Attributes();
			at.putAll(map);
			ProvisioningPlan.AttributeRequest attribute = new ProvisioningPlan.AttributeRequest();
			attribute.setValue(groupid);
			if(op.equalsIgnoreCase("add")) {
				attribute.setOp(ProvisioningPlan.Operation.Add);
				eventAt.put("Operation", "add group");
			}
			else {
				attribute.setOp(ProvisioningPlan.Operation.Remove);
				eventAt.put("Operation", "remove group");
			}
			attribute.setName("groups");
			attribute.setArgs(at);
			eventAt.put("groupname", groupname);
			eventAt.put("group id", groupid);
			requestAccount.add(attribute);
			plan.add(requestAccount);
			log.trace(plan.toXml());

			//Step 3: execute provisioning plan
			Provisioner p = new Provisioner(context);
			p.execute(plan);
			log.trace("added user to group");


			//Step 4: Call Audit event
			String action = "EntitlementAdd";
			if(op.equalsIgnoreCase("remove")) {
				action = "EntitlementRemove";
			}
			createAuditEvent(action, username, groupid, "group", eventAt);

		}catch(Exception e) {
			log.trace(e);
		}

		log.trace("Exiting groupUpdate......");
		responseString = "Success";
		response = Response.status(Response.Status.OK).entity(responseString).build();
		return response;
	}

	@PUT
	@Path("addRemoveEligibleRole")
	public Response addRemoveEligibleRole(Map<String, Object> request) throws GeneralException, SQLException, ParseException {
		log.trace("Entering addRemoveEligibleRole...");
		SailPointContext context = SailPointFactory.getCurrentContext();
		String username = (String)request.get("username");
		String rolename = (String)request.get("rolename");
		String op = (String)request.get("operation");
		String roleid = null;
		String nativeIdentity = null;
		String responseString = null;
		boolean removeRole = false;
		List identityEligibleRoles = new ArrayList();
		log.trace("username:"+username);
		log.trace("rolename:"+rolename);

		try {
			log.trace("cheking if identity exists...");
			Identity identity = context.getObjectByName(Identity.class, username);
			if(Util.isNullOrEmpty(username)||Util.isNullOrEmpty(rolename)||Util.isNullOrEmpty(op)) {
				responseString = "Mandatory inputs missing";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}
			if(identity == null) {
				responseString = "User is not present in IIQ";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}else {
				log.debug("get Entra ID link for user and find the object ID");
				List links = identity.getLinks();
				Iterator linkIt = links.iterator();
				while(linkIt.hasNext()) {
					Link li = (Link) linkIt.next();
					log.trace("link application::"+li.getApplicationName()+" Native identity::"+li.getNativeIdentity());
					if(li.getApplicationName().equalsIgnoreCase(applicationName)) {
						nativeIdentity=li.getNativeIdentity();
						log.debug("identity eligible roles::"+li.getAttribute("azureADEligibleRoles"));
						List temp = (List) li.getAttribute("azureADEligibleRoles");
						if(!Util.isEmpty(temp)) {
							identityEligibleRoles.addAll(Util.otol(li.getAttribute("azureADEligibleRoles"), true));
						}

					}
				}
			}

			if(nativeIdentity == null) {
				responseString = "User does not have EntraID Account";
				log.trace(responseString);
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}


			ProvisioningPlan plan = new ProvisioningPlan();
			// Operation: Add user to EntraID Eligible Role
			//Step1: Check if Group Exists
			log.trace("Checking if group exists...");
			List managedAttr = getManagedObjects(context,applicationName, "azureADEligibleRoles", rolename);
			if(managedAttr!=null && managedAttr.size()>0) {
				log.trace("role found");
				Iterator itr = managedAttr.iterator();
				while(itr.hasNext()) {
					ManagedAttribute at = (ManagedAttribute) itr.next();
					log.trace("attribtue value used to build the plan::"+at.getValue());
					roleid = at.getValue();		  			
				}
				sailpoint.tools.Util.flushIterator(itr);

			}else {
				log.trace("EntraID role does not exist in SailPoint. Run the EntraID aggregation and verify if role is present in SailPoint");
				responseString = "EntraID role does not exist in SailPoint. Run the EntraID aggregation and verify if role is present in SailPoint";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
				return response;
			}

			log.debug("op::"+op);


			//Step 1: Check if user has the group
			if(identityEligibleRoles == null || identityEligibleRoles.isEmpty()) {
				log.error("User does not have any EntraID Eligible role assignments");
			}else {
				log.debug("iterating EligibleRoles::"+identityEligibleRoles.size());
				Iterator roleItr = identityEligibleRoles.iterator();
				while (roleItr.hasNext()) {
					String temp = roleItr.next().toString();
					log.debug(temp+"::"+roleid);
					if(temp.equals(roleid)) {
						removeRole = true;
						break;
					}
				}
			}
			log.debug(removeRole);
			if(op.equalsIgnoreCase("remove")) {
				if(!removeRole) {
					log.error("Remove role fail: User does not have the EntraID Eligible role assignment");
					responseString = "Remove role fail: User does not have the EntraID Eligible role assignment";
					response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build(); 
					return response;
				}
			}else if(op.equalsIgnoreCase("add")) {
				if(removeRole) {
					log.error("User already has the EntraID eligble role assigned");
					responseString = "User already has the EntraID eligble role assigned";
					response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
					return response;
				}
			}else {
				log.error("Invalid Operation");
				responseString = "Invalid Operation";
				response = Response.status(Response.Status.BAD_REQUEST).entity(responseString).build();
				return response;

			}
			log.debug("bulding plan for eligible role update::"+roleid+"::native identity::"+nativeIdentity);

			//Step 2: Build provisioning plan to add user to group
			Attributes eventAt = new Attributes();
			eventAt.put("identity", identity.getDisplayableName());
			plan.setIdentity(identity);
			eventAt.put("Application", applicationName);
			ProvisioningPlan.AccountRequest requestAccount = new ProvisioningPlan.AccountRequest();
			requestAccount = new ProvisioningPlan.AccountRequest();
			requestAccount.setNativeIdentity(nativeIdentity);
			requestAccount.setOperation(ProvisioningPlan.AccountRequest.Operation.Modify);
			requestAccount.setApplication(applicationName);
			Map map = new HashMap();
			map.put("assignment", "true");
			Attributes at = new Attributes();
			at.putAll(map);
			ProvisioningPlan.AttributeRequest attribute = new ProvisioningPlan.AttributeRequest();
			attribute.setValue(roleid);
			if(op.equalsIgnoreCase("add")) {
				attribute.setOp(ProvisioningPlan.Operation.Add);
				eventAt.put("Operation", "add azureADEligibleRoles");
			}
			else {
				attribute.setOp(ProvisioningPlan.Operation.Remove);
				eventAt.put("Operation", "remove azureADEligibleRoles");
			}
			attribute.setName("azureADEligibleRoles");
			attribute.setArgs(at);
			eventAt.put("azureADEligibleRole Name", rolename);
			eventAt.put("azureADEligibleRole id", roleid);
			requestAccount.add(attribute);
			plan.add(requestAccount);
			log.trace(plan.toXml());

			//Step 3: execute provisioning plan
			Provisioner p = new Provisioner(context);
			p.execute(plan);
			log.trace("added user to group");


			//Step 4: Call Audit event
			String action = "EntitlementAdd";
			if(op.equalsIgnoreCase("remove")) {
				action = "EntitlementRemove";
			}
			createAuditEvent(action, username, roleid, "azureADEligibleRoles", eventAt);	

		}catch(Exception e) {
			log.trace(e);
		}

		log.trace("Exiting addRemoveEligibleRole......");
		responseString = "Success";
		response = Response.status(Response.Status.OK).entity(responseString).build();
		return response;

	}
}
