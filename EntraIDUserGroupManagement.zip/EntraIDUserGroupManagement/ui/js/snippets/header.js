var exampleURL = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=EntraIDUserGroupManager';
jQuery(document).ready(function(){
    jQuery("ul.navbar-right li:first")
        .before(
            '<li class="dropdown">' +
            '		<a href="' + exampleURL + '" tabindex="0" role="menuitem" title="Example Plugin Settings Page">' +
            '			<i role="presenation" class="fa fa fa-envelope fa-lg"></i>' +
            '		</a>' +
            '</li>'
        );
});
